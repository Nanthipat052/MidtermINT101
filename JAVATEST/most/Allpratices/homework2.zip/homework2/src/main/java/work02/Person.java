package work02;

import work01.Utilitor;

public class Person {
    private static int nextId = 1;
    private final int id;
    private String firstName;
    private String lastName;

    public Person(String firstName, String lastName){
        this.firstName = Utilitor.testString(firstName);
        this.lastName = Utilitor.testString(lastName);
        this.id = nextId++;
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append(this.id).append(", ");
        s.append(this.firstName).append(", ");
        s.append(this.lastName);
        return s.toString();
    }

    public boolean equals(Person obj){
        if(this == obj) return true;
        return false;
    }
}
