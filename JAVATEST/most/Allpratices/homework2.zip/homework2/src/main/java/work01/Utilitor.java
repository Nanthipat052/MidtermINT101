package work01;

public class Utilitor {
    public static String testString(String value){
        if(value.equals(null)){
            throw new NullPointerException();
        }else if(value.isBlank()){
            throw new IllegalArgumentException();
        }
        return value;
    }

    public static double testPositive(double value){
        if(value < 0) throw new IllegalArgumentException();
        return value;
    }

    public static long computeIsbn10(long isbn10){
        long result = 0;
        for(int i = 2;isbn10 != 0;i++){
            result += (isbn10 % 10) * i;
            isbn10 = isbn10 / 10;
        }
        long lastIndex = 11 - (result % 11) ;
        return (result % 11) == 0 ? 0 : lastIndex;
    }
}
